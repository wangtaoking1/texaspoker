package utils;

public enum Color {
    SPADES,         //黑桃
    HEARTS,         //红桃
    CLUBS,          //梅花
    DIAMONDS        //方片
}
